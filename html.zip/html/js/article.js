
$(function () {
    var flag=false;
    jQuery.validator.addMethod("lettersonly", function (value, element) {
        return this.optional(element) || /^[a-z," "]+$/i.test(value);
    }, "Letters only please");

    $("#articleForm").validate({
        errorElement: "div",
        debug: true,
        rules: {
            article_name: {
                required: true,
                //lettersonly: true
            },
            author_name: {
                required: true,
                //lettersonly: true
            },
            email_id: {
                required: true,
                email: true
            },
            content: {
                required: true,
            },
        },
        errorPlacement: function (error, element) {
            if (element.attr("name") == "gender") {
                error.appendTo('#Parent_access');

            } else {
                error.insertAfter(element);
            }
        },
        submitHandler: function (form) {
            var app_url = 'http://localhost:9001';
            var regex_email = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,3}$/i;
            var regex_name = /^[a-zA-Z ]{2,30}$/;
            var author_name=$('#author_name').val();
            var article_name=$('#article_name').val();
            var email_id=$('#email_id').val();
            var content=$('#content').val();
            console.log(author_name);
            if(email_id)
            {
                var data={
                    "author_name":author_name,
                    "article_name":article_name,
                    "email_id":email_id,
                    "content":content,
                }

                $.ajax({
                    url: app_url+'/articleSave/',
                    type: 'POST',
                    data: data,
                    success: function (data) {
                        console.log("dagta"+data);
                        //sessionStorage.email=email;
                        window.location.href = "index.html";
                        //window.location.href = "dashboard.html";
                    },
                    error: function (error) {
                        document.getElementById("ServerError").innerHTML == ""
                        if (error.status == 500) {
                                $('#ServerError').append('<small>Could not connect to the server, please try after sometime.</small>');
                        }
                    }

                });
            }
        }
    });


});

