    var app_url = 'http://localhost:9001';

    function likes(article_id) {
        var email_id = prompt("Please enter your email_id:", "");
        if (email_id == null || email_id == "") {
            //do nothing
        } else {
            data = {
                'article_id': article_id,
                 'email_id': email_id
            }
            console.log(data);
            $.ajax({
                url: app_url + '/saveLikes/',
                type: "POST",
                data: data,
                success: function (success) {
                    location.reload();
                },
                error: function (error) {
                    $('#error_msg').show();
                 }           
            });
        }

            //event.preventDefault();
    }            

$(function () {


    $.ajax({
        url: app_url + '/articles/',
        type: "GET",
        //data: data,
        //headers: {'content-type': 'application/json;'},
        success: function (data) {
            console.log(data);
            if(data){
            item_data=data;
                for(i=0;i<data.length;i++)
                    {
                        var article_content='<div class="panel panel-default"><div class="panel-body">'
                          +'    <div class="col-sm-offset-4 col-sm-5"><h3 class="article-header">'+data[i].article_name+'</h3></div>'
                          +'    <div class="col-lg-12 col-md-12 mx-auto art-box">'
                          +'          <p>'+data[i].content+'</p>'
                          +'     </div>'
                          +'</div>'
                          +'  <div class="panel-footer">'
                          +'  <h4>Likes: '+data[i].likes+'</h4>'
                          +'      <span class="pull-right">'
                          +'  <a href="" onclick="likes('+data[i].id+')"><i id="like3" class="glyphicon glyphicon-thumbs-up"></i> <div id="like3-bs3"></div></a>'
                          +'  <i id="dislike3" class="glyphicon glyphicon-thumbs-down"></i> <div id="dislike3-bs3"></div>'
                          +'</span>'
                          +'</div></div>';
                        $('#article_list').append(article_content);
                    }    
            }
            else{
            }
        },
        error: function (error) {
            console.log(error);
            $('#error_msg').show();
        }           
	});
            //event.preventDefault();


});