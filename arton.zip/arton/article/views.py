"""Views to access and save articles"""
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.core.exceptions import ObjectDoesNotExist
from article.models import Articles, UserLikes
from article.articleSerializers import ArticleSerializer

@method_decorator(csrf_exempt, name='dispatch')
class SaveArticle(APIView):
    """ Save Article"""
    def get(self, request):
        """ Get Article"""
        articles = Articles.objects.filter(content__isnull=False)
        articles = ArticleSerializer(articles, many=True, context={'request': request})
        return Response(articles.data)
    def post(self, request):
        """ Post Article"""
        now = datetime.now()
        email_id = request.data.get('email_id')
        article_title = request.data.get('article_title')
        article_name = request.data.get('article_name')
        content = request.data.get('content')
        article_obj = Articles()
        article_obj.email_id = email_id
        article_obj.article_title = article_title
        article_obj.article_name = article_name
        article_obj.date_added = now
        article_obj.content = content
        article_obj.save()
        articles = Articles.objects.filter(content__isnull=False)
        articles = ArticleSerializer(articles, many=True, context={'request': request})
        return Response(articles.data)

@method_decorator(csrf_exempt, name='dispatch')
class SaveLikes(APIView):
    """ Save Likes"""
    def post(self, request):
        """ Post Likes """
        email_id = request.data.get('email_id')
        article_id = request.data.get('article_id')
        #likes=request.data.get('likes')
        #try:
        article_obj = Articles.objects.get(id=article_id)
        try:
            likes_obj = UserLikes.objects.get(article_id=article_obj, email_id=email_id)
        except ObjectDoesNotExist:
            likes_obj = UserLikes()
        likes_obj.article_id = article_obj
        likes_obj.email_id = email_id
        likes_obj.likes = True
        #likes_obj.date_added=now
        likes_obj.save()
        #except:
        #    pass
        articles = Articles.objects.filter(content__isnull=False)
        articles = ArticleSerializer(articles, many=True, context={'request': request})
        return Response(articles.data)
