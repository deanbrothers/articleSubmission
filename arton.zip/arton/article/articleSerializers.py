""" Serializers to access article information """
from django.contrib.auth.models import User, Group
from rest_framework import serializers
from article.models import Articles, UserLikes



class ArticleSerializer(serializers.HyperlinkedModelSerializer):
    """ Article Serializer"""
    likes=serializers.SerializerMethodField('get_likes_count')

    def get_likes_count(self, article):
        """ Get Likes """
        likes = UserLikes.objects.filter(article_id=article).count()
        return likes


    class Meta:
        """ Get Meta """
        model = Articles
        fields = ('id', 'article_name', 'author_name', 'email_id', 'content', 'likes')


