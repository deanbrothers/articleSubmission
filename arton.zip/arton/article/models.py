"""Articles models"""
# -*- coding: utf-8 -*-
from django.db import models
from django.shortcuts import render
# Create your views here.


# Create your models here.
class Articles(models.Model):
    """Models to save articles"""
    article_name = models.CharField(max_length=50)
    author_name = models.CharField(max_length=50)
    email_id = models.CharField(max_length=100)
    content = models.CharField(max_length=255)
    date_added = models.DateTimeField()
    def __str__(self):
        return self.article_name
    def __init__(self):
        return self.name

class UserLikes(models.Model):
    """Models to save user likes"""
    article_id = models.ForeignKey(Articles)
    email_id = models.CharField(max_length=100)
    likes=models.BooleanField(default=True)
    def __str__(self):
        return self.email_id
    def __init__(self):
        return self.name
